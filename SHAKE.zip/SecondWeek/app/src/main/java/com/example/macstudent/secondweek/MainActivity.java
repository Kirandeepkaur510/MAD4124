package com.example.macstudent.secondweek;

import android.content.Context;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener{

    boolean lightOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 1. Create a bunch of nonsense variables
        // that are used to create when phone is shaking
        // set up ur phone to deal with shake

        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);

    }
    //this is mandatory function
    //it is required by the shakeDetector.Listener
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void hearShake() {
       //2. this function automatically gets called
       // every time you shake the phone

        //turn on flashlight when phone shakes
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);


        //1. whcich camera do you want to ON front/back
        try {
            String cameraID = cameraManager.getCameraIdList()[0]; //BACK CAMERA
            //turn ON
            //2. turn the flash on
            if(lightOn == false){
                cameraManager.setTorchMode(cameraID,true);
                Log.d("KIRAN", "Turning flash ON!");

                Toast.makeText(this,"Turning flash ON",Toast.LENGTH_SHORT).show();
                lightOn = true;
            }
            else
            {
                cameraManager.setTorchMode(cameraID,false);
                Log.d("KIRAN", "Turning flash OFF!");
                Toast.makeText(this,"Turning flash ON",Toast.LENGTH_SHORT).show();
                lightOn = false;
            }

            //turn OFF
            //cameraManager.setTorchMode(cameraID,false);
        }
        catch (CameraAccessException e) {
            Log.d("KIRAN" , "Errorr......");
            Toast.makeText(this,"Error fetching camera ID",Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }




    }
}
