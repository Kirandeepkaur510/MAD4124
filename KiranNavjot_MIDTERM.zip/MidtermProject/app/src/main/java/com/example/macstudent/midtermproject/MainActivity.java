package com.example.macstudent.midtermproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements myAdapter.ItemClickListener {

    //OKHttp variable
    OkHttpClient client = new OkHttpClient();
    TextView textviewMain;
    private myAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        final RecyclerView recyclerView = findViewById(R.id.recycleView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        LinearLayoutManager mlm = (LinearLayoutManager) recyclerView.getLayoutManager();

        //setting adapter variable


        Request q = new Request.Builder()
                .url("https://api.darksky.net/forecast/ff41689fc242d7783a79fab7ae586b2b/45.4215,-75.6972?exclude=currently")
                .build();
        client.newCall(q).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("KIRAN", "failed!");

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                Log.d("KIRAN", "success!!");

                if (response.isSuccessful()) {
                    final String reply = response.body().string();

                   // Log.d("KIRAN", reply);

                    // convert to JSON
                    try {
                        JSONObject json = new JSONObject(reply);

                        // parse the json
                        double lat = json.getDouble("latitude");
                        String timeZone = json.getString("timezone");

                        JSONObject currentWeather = json.getJSONObject("currently");
                        String conditions = currentWeather.getString("summary");
                        String temperature = currentWeather.getString("temperature");


                        Log.d("KIRAN", "Latitude: " + Double.toString(lat));
                        Log.d("KIRAN", "Timezone: " + timeZone);
                        Log.d("KIRAN", "Weather conditions: " + conditions);
                       // Log.d("KIRAN", "Temparture: " + temperature);

                    }
                    catch (Exception e) {
                        Log.d("KIRAN", "Error while parsing");
                    }
//output json response to the terminal
                    Log.d("Kiran" ,reply);

                    //output to userinterface
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run()
                        {
                            //put the code here for UI
                            //ui nonsense

                            mAdapter = new myAdapter(this, reply);
                            mAdapter.setClickListener(this); //to deal with clicks
                            recyclerView.setAdapter(mAdapter);


                        }
                    });

                }
                else {
                    Log.d("KIRAN", "there was a problem with the response");
                }

            }
        });

    }


    @Override
    public void onItemClick(View view, int position) {

    }
}
